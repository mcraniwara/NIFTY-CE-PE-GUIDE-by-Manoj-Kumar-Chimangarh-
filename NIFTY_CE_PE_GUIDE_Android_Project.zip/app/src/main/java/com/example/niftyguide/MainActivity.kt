package com.example.niftyguide

import android.app.Activity
import android.os.Bundle
import android.graphics.Color
import android.view.Gravity
import android.widget.*

class MainActivity : Activity() {
    private val bg = Color.rgb(7,17,29)
    private val card = Color.rgb(13,27,43)
    private val green = Color.rgb(57,231,95)
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        val scroll = ScrollView(this)
        scroll.setBackgroundColor(bg)
        val box = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(28,28,28,90)
        }
        fun tv(text:String, size:Float, color:Int=Color.WHITE): TextView =
            TextView(this).apply { this.text=text; textSize=size; setTextColor(color); setPadding(0,8,0,8) }
        fun card(text:String): TextView = tv(text,16f).apply {
            setBackgroundColor(this@MainActivity.card); setPadding(24,20,24,20)
        }

        box.addView(tv("⚡ NIFTY CE/PE GUIDE",24f,Color.WHITE))
        box.addView(tv("Smart Trading Guide • Android Prototype",13f,Color.LTGRAY))
        box.addView(card("NIFTY 50  •  DEMO DATA\n\n24,152.35\n+181.45 (+0.76%) ↑"))
        box.addView(card("HIGH CONFIDENCE\n\n↑ BUY CALL (CE)\nBullish momentum • Multiple confirmations").apply {
            setTextColor(green)
        })
        box.addView(card("Support       24,050\nResistance   24,250\nVWAP          24,097  • Above\nRSI (14)       62.3  • Bullish"))
        box.addView(card("🎯 TRADE PLAN (DEMO)\n\nBest Strike: 24,200 CE\nEntry: Confirmation के बाद\nStop Loss: Rule-based\nTarget: Rule-based"))
        box.addView(card("🏦 OPTION CHAIN SNAPSHOT\n\nStrike      CE OI      PE OI\n24,100      +15.2%     +7.1%\n24,200      +12.5%     +5.3%\n24,300       +9.8%     +3.9%"))
        box.addView(card("🛡 RISK MANAGEMENT\n\nCapital: ₹1,50,000\nRisk / Trade: 1%\nMaximum Risk: ₹1,500"))
        val btn = Button(this).apply {
            text = "CHECK LIVE SIGNAL"
            setOnClickListener { Toast.makeText(this@MainActivity, "Live market API अभी जोड़ी जानी है।", Toast.LENGTH_LONG).show() }
        }
        box.addView(btn)
        box.addView(tv("⚠️ Prototype: अभी Demo Data है। Live API, broker/data-source integration और testing के बाद ही वास्तविक trading guidance के लिए उपयोग करें। कोई signal लाभ की गारंटी नहीं देता।",12f,Color.LTGRAY))
        scroll.addView(box)
        setContentView(scroll)
    }
}
