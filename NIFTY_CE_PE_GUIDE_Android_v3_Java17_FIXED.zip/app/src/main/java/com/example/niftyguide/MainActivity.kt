package com.example.niftyguide

import android.app.Activity
import android.os.Bundle
import android.graphics.Color
import android.widget.*

class MainActivity : Activity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        val scroll = ScrollView(this)
        scroll.setBackgroundColor(Color.rgb(7,17,29))
        val box = LinearLayout(this)
        box.orientation = LinearLayout.VERTICAL
        box.setPadding(24,24,24,80)

        fun text(s:String, size:Float, color:Int=Color.WHITE) =
            TextView(this).apply {
                text=s; textSize=size; setTextColor(color); setPadding(0,10,0,10)
            }

        fun card(s:String) = text(s,16f).apply {
            setBackgroundColor(Color.rgb(13,27,43))
            setPadding(20,18,20,18)
        }

        box.addView(text("⚡ NIFTY CE/PE GUIDE",24f))
        box.addView(text("Smart Trading Guide • Demo Version",13f,Color.LTGRAY))
        box.addView(card("NIFTY 50 • DEMO DATA\n\n24,152.35\n+181.45 (+0.76%) ↑"))
        box.addView(card("HIGH CONFIDENCE\n\n↑ BUY CALL (CE)\nBullish momentum • Multiple confirmations")
            .apply { setTextColor(Color.rgb(57,231,95)) })
        box.addView(card("Support       24,050\nResistance   24,250\nVWAP          24,097 • Above\nRSI (14)       62.3 • Bullish"))
        box.addView(card("🎯 TRADE PLAN\n\nBest Strike: 24,200 CE\nEntry: Confirmation के बाद\nStop Loss: Rule-based\nTarget: Rule-based"))
        box.addView(card("🏦 OPTION CHAIN\n\nStrike      CE OI      PE OI\n24,100      +15.2%     +7.1%\n24,200      +12.5%     +5.3%\n24,300       +9.8%     +3.9%"))
        box.addView(card("🛡 RISK MANAGEMENT\n\nCapital: ₹1,50,000\nRisk / Trade: 1%\nMaximum Risk: ₹1,500"))
        box.addView(Button(this).apply {
            text="CHECK LIVE SIGNAL"
            setOnClickListener {
                Toast.makeText(this@MainActivity,"अभी Demo Data है। Live API बाद में जोड़ी जाएगी।",Toast.LENGTH_LONG).show()
            }
        })
        box.addView(text("⚠️ Demo Prototype है। Live market data के बिना वास्तविक trade में signal का उपयोग न करें। कोई signal लाभ की गारंटी नहीं देता।",12f,Color.LTGRAY))
        scroll.addView(box)
        setContentView(scroll)
    }
}
